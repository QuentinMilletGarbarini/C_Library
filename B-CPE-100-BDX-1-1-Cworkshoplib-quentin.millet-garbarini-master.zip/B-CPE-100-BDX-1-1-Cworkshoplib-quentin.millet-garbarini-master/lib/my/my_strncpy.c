/*
** EPITECH PROJECT, 2020
** my_strncpy
** File description:
** 
*/

char my_strncpy(char *dest, char const *src, int n)
{
    return (0);
}
