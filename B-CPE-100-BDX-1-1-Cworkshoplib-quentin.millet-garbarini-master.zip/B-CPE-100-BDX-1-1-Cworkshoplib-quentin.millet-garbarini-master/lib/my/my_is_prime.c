/*
** EPITECH PROJECT, 2020
** my_is_prime
** File description:
** 
*/

int my_compute_square_root(int nb)
{
    return (0);
}
