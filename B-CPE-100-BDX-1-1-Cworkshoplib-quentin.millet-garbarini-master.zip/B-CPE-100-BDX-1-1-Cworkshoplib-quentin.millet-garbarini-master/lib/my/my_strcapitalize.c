/*
** EPITECH PROJECT, 2020
** my_strcapitalize
** File description:
** 
*/

char my_strcapitalize(char *str)
{
    return (0);
}
