/*
** EPITECH PROJECT, 2020
** my_compute_square_root
** File description:
** 
*/

int my_compute_square_root(int nb)
{
    return (0);
}
