/*
** EPITECH PROJECT, 2020
** my_find_prime_sup
** File description:
** 
*/

int my_find_prime_sup(int nb)
    
{
    return (0);
}
