/*
** EPITECH PROJECT, 2020
** my_showstr
** File description:
** 
*/

int my_showstr(char const *str)
{
    return (0);
}
