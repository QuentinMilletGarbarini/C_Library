/*
** EPITECH PROJECT, 2020
** my_strncat
** File description:
** 
*/

char my_strncat(char *dest, char const *src, int nb)
{
    return (0);
}
