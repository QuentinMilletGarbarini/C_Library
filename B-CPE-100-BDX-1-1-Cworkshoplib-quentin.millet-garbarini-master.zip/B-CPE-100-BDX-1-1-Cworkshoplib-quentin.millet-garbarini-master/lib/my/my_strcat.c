/*
** EPITECH PROJECT, 2020
** my_strcat
** File description:
** 
*/

char my_strcat(char *dest, char const *src)
{
    return (0);
}
