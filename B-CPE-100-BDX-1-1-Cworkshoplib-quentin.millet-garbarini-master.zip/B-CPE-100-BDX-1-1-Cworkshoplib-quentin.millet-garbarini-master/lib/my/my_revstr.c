/*
** EPITECH PROJECT, 2020
** my_revstr
** File description:
** 
*/

char my_revstr(char *str)
{
    return (0);
}
