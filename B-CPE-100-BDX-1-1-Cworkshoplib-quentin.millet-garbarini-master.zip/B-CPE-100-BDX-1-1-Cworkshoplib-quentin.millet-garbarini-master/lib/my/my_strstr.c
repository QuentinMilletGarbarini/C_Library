/*
** EPITECH PROJECT, 2020
** my_strstr
** File description:
** 
*/

char my_strstr(char *str, char const *to_find)
{
    return (0);
}
