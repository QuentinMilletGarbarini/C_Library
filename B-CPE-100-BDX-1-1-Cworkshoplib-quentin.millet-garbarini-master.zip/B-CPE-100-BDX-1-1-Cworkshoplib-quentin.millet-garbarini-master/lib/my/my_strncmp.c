/*
** EPITECH PROJECT, 2020
** my_strncmp
** File description:
** 
*/

int my_strncmp(char const *s1, char const *s2, int n)
{
    return (0);
}
