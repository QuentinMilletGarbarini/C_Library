/*
** EPITECH PROJECT, 2020
** my_showmem
** File description:
** 
*/

int my_showmem(char const *str, int size)
{
    return (0);
}
