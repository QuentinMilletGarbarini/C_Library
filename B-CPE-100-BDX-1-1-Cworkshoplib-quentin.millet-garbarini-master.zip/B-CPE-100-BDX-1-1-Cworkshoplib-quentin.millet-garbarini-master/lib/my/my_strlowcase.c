/*
** EPITECH PROJECT, 2020
** my_strlowcase
** File description:
** 
*/

char my_strlowcase(char *str)
{
    return (0);
}
