/*
** EPITECH PROJECT, 2020
** my_compute_power_rec
** File description:
** 
*/

int my_compute_power_rec(int nb, int power)
{
    return (0);
}
