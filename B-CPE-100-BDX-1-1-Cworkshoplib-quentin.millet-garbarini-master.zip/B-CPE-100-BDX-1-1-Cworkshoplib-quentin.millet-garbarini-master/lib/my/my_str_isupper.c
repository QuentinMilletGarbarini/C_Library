/*
** EPITECH PROJECT, 2020
** my_str_isupper
** File description:
** 
*/

int my_str_isupper(char const *str)
{
    return (0);
}
