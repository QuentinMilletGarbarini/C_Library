/*
** EPITECH PROJECT, 2020
** my_strupcase 
** File description:
** 
*/

char my_strupcase(char *str)
{
    return (0);
}
